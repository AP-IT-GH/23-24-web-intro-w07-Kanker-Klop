# 💻 07. Bootstrap & koffie > oefening 01

## 🛠️ opdrachten

### html-pagina's samenbrengen
 - [ ] Breng de 2 pagina's [`shop.html`](shop.html) en  [`contact.html`](contact.html) samen.

### head
 - [ ] Ga alle kopellingen na en zorg dat ze correct werken: css en js van Bootstrap, iconen van Bootstrap en eigen css.

#### nav
- [ ] Zorg dat alle pagina’s naar elkaar verwijzen in de nav.

#### footer
- [ ] Zorg dat elke pagina dezelfde footer heeft.

#### bestandstructuur
- [ ] Zorg dat de naamgeving is van bestanden en mappen, conform is, zoals we in de theorie zagen. 

#### zip-bestand op Digitap
- [ ] Wanneer je deze oefening hebt afgewerkt, kan je op je `Github Repo` gaan naar de knop `Code` > `Download ZIP`. Upload deze zip in de uploadzone op Digitap. Nadien corrigeer je zelf jouw labo op basis van de correctiesleutel op Digitap, om zo te leren uit jouw fouten.
